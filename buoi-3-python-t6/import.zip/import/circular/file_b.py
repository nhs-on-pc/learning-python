import file_a
print("This is file B")
