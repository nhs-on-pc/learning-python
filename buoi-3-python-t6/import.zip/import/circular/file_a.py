import file_b

print("This is file A")


def a_do_something():
    print("A do something")