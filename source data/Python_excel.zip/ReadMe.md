pandas làm việc với Excel rất tiện dụng
pyexcel đọc được nhiều kiểu dữ liệu
openpyxl rất chuyên để đọc/ghi Excel

Ý tưởng tiếp theo là xử lý dữ liệu và xuất báo cáo

https://www.dataquest.io/blog/excel-and-pandas/

